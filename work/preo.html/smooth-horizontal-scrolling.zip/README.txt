A Pen created at CodePen.io. You can find this one at https://codepen.io/colinlord/pen/oZNoOO.

 A demonstration of two ways to horizontally scroll content within a container div. One uses inline-block and the other uses flexbox.