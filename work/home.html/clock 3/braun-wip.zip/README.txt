A Pen created at CodePen.io. You can find this one at https://codepen.io/chrisota/pen/JoYWQM.

 WIP watch. Pure HTML and CSS.

To do: add Braun logo, watch dial, shading, details, etc etc. Hopefully I don't get lazy.