A Pen created at CodePen.io. You can find this one at https://codepen.io/andrewsheffield/pen/qZedNE.

 AnoClock is an analog clock plug in for jQuery that lets you implement web based analog clocks quickly and with little coding.